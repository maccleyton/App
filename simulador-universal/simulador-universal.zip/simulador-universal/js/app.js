// app.js - Arquivo principal da aplicação
class App {
    constructor() {
        this.sceneManager = null;
        this.physicsEngine = null;
        this.currentSimulator = null;
        this.simulators = {};
        this.isPlaying = false;
        this.simulationSpeed = 1.0;
        this.lastTime = 0;
        this.fps = 60;

        this.init();
    }

    init() {
        console.log('🚀 Inicializando aplicação...');

        // Inicializar managers
        this.sceneManager = new SceneManager('canvas3d');
        this.physicsEngine = new PhysicsEngine();

        // Criar simuladores
        this.simulators = {
            nuclear: new NuclearSimulator(this.sceneManager, this.physicsEngine),
            physics: new PhysicsSimulator(this.sceneManager, this.physicsEngine),
            cosmic: new CosmicSimulator(this.sceneManager, this.physicsEngine),
            molecular: new MolecularSimulator(this.sceneManager, this.physicsEngine),
            biological: new BiologicalSimulator(this.sceneManager, this.physicsEngine),
            archaeological: new ArchaeologicalSimulator(this.sceneManager, this.physicsEngine),
            thermodynamic: new ThermodynamicSimulator(this.sceneManager, this.physicsEngine),
            climatic: new ClimaticSimulator(this.sceneManager, this.physicsEngine)
        };

        // Iniciar com simulador nuclear
        this.switchSimulator('nuclear');

        // Setup UI
        this.setupUI();

        // Iniciar loop de animação
        this.animate();

        console.log('✅ Aplicação inicializada com sucesso!');
    }

    setupUI() {
        // Navegação entre simuladores
        document.querySelectorAll('.nav-menu li').forEach(item => {
            item.addEventListener('click', (e) => {
                const simulatorName = e.currentTarget.dataset.simulator;
                this.switchSimulator(simulatorName);

                // Atualizar menu ativo
                document.querySelectorAll('.nav-menu li').forEach(li => li.classList.remove('active'));
                e.currentTarget.classList.add('active');
            });
        });

        // Controles de simulação
        document.getElementById('btn-play').addEventListener('click', () => this.play());
        document.getElementById('btn-pause').addEventListener('click', () => this.pause());
        document.getElementById('btn-reset').addEventListener('click', () => this.reset());

        // Slider de velocidade
        document.getElementById('speed-slider').addEventListener('input', (e) => {
            this.simulationSpeed = parseFloat(e.target.value);
            document.getElementById('speed-value').textContent = this.simulationSpeed.toFixed(1) + 'x';
        });

        // Controles físicos universais
        document.getElementById('temp-slider').addEventListener('input', (e) => {
            const temp = parseFloat(e.target.value);
            document.getElementById('temp-value').textContent = temp;
            if (this.currentSimulator && this.currentSimulator.setTemperature) {
                this.currentSimulator.setTemperature(temp);
            }
        });

        document.getElementById('pressure-slider').addEventListener('input', (e) => {
            const pressure = parseFloat(e.target.value);
            document.getElementById('pressure-value').textContent = pressure.toFixed(1);
            if (this.currentSimulator && this.currentSimulator.setPressure) {
                this.currentSimulator.setPressure(pressure);
            }
        });

        document.getElementById('gravity-slider').addEventListener('input', (e) => {
            const gravity = parseFloat(e.target.value);
            document.getElementById('gravity-value').textContent = gravity.toFixed(1);
            this.physicsEngine.setGravity(0, -gravity, 0);
        });

        document.getElementById('magnetic-slider').addEventListener('input', (e) => {
            const magnetic = parseFloat(e.target.value);
            document.getElementById('magnetic-value').textContent = magnetic.toFixed(1);
            if (this.currentSimulator && this.currentSimulator.setMagneticField) {
                this.currentSimulator.setMagneticField(magnetic);
            }
        });

        // Toggle painel
        document.getElementById('toggle-panel').addEventListener('click', () => {
            const panelBody = document.getElementById('panel-content');
            const toggleBtn = document.getElementById('toggle-panel');

            if (panelBody.style.display === 'none') {
                panelBody.style.display = 'block';
                toggleBtn.textContent = '▼';
            } else {
                panelBody.style.display = 'none';
                toggleBtn.textContent = '▲';
            }
        });
    }

    switchSimulator(name) {
        console.log(`🔄 Mudando para simulador: ${name}`);

        // Cleanup do simulador atual
        if (this.currentSimulator) {
            if (this.currentSimulator.cleanup) {
                this.currentSimulator.cleanup();
            }
            this.pause();
        }

        // Limpar cena e física
        this.sceneManager.clearScene();
        this.physicsEngine.reset();

        // Ativar novo simulador
        const simulator = this.simulators[name];

        if (simulator) {
            this.currentSimulator = simulator;
            if (simulator.init) {
                simulator.init();
            }

            // Atualizar título
            const titles = {
                nuclear: 'Simulador Nuclear',
                physics: 'Simulador Físico',
                cosmic: 'Simulador Cósmico',
                molecular: 'Simulador Molecular',
                biological: 'Simulador Biológico',
                archaeological: 'Simulador Arqueológico',
                thermodynamic: 'Simulador Termodinâmico',
                climatic: 'Simulador Climático'
            };

            document.getElementById('simulator-title').textContent = titles[name] || 'Simulador';

            // Auto-play
            setTimeout(() => this.play(), 500);
        } else {
            console.warn(`⚠️ Simulador ${name} ainda não implementado`);
        }
    }

    play() {
        this.isPlaying = true;
        if (this.currentSimulator && this.currentSimulator.start) {
            this.currentSimulator.start();
        }
        document.getElementById('btn-play').style.opacity = '0.5';
        document.getElementById('btn-pause').style.opacity = '1';
        console.log('▶️ Simulação iniciada');
    }

    pause() {
        this.isPlaying = false;
        if (this.currentSimulator && this.currentSimulator.pause) {
            this.currentSimulator.pause();
        }
        document.getElementById('btn-play').style.opacity = '1';
        document.getElementById('btn-pause').style.opacity = '0.5';
        console.log('⏸️ Simulação pausada');
    }

    reset() {
        this.pause();
        if (this.currentSimulator && this.currentSimulator.reset) {
            this.currentSimulator.reset();
        }
        this.physicsEngine.reset();
        console.log('🔄 Simulação resetada');
    }

    animate(time = 0) {
        requestAnimationFrame((t) => this.animate(t));

        // Calcular delta time
        const deltaTime = (time - this.lastTime) / 1000;
        this.lastTime = time;

        // Calcular FPS
        if (deltaTime > 0) {
            this.fps = Math.round(1 / deltaTime);
            document.getElementById('fps-value').textContent = this.fps;
        }

        if (this.isPlaying) {
            // Atualizar física
            this.physicsEngine.update(deltaTime * this.simulationSpeed);

            // Atualizar simulador atual
            if (this.currentSimulator && this.currentSimulator.update) {
                this.currentSimulator.update(deltaTime * this.simulationSpeed);
            }
        }

        // Renderizar cena
        this.sceneManager.render();
    }
}

// Iniciar aplicação quando DOM estiver pronto
document.addEventListener('DOMContentLoaded', () => {
    window.app = new App();
});