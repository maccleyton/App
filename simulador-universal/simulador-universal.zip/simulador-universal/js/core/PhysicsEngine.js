// PhysicsEngine.js - Motor de física com Cannon.js
class PhysicsEngine {
    constructor() {
        this.world = null;
        this.bodies = [];
        this.meshes = [];
        this.timeStep = 1 / 60;
        this.init();
    }

    init() {
        // Criar mundo de física
        this.world = new CANNON.World();
        this.world.gravity.set(0, -9.82, 0);

        // Configurações de performance
        this.world.broadphase = new CANNON.NaiveBroadphase();
        this.world.solver.iterations = 10;
        this.world.allowSleep = true;

        console.log('✅ PhysicsEngine inicializado');
    }

    setGravity(x, y, z) {
        this.world.gravity.set(x, y, z);
    }

    createSphere(radius, mass, position) {
        const shape = new CANNON.Sphere(radius);
        const body = new CANNON.Body({
            mass: mass,
            shape: shape,
            position: new CANNON.Vec3(position.x, position.y, position.z)
        });

        this.world.addBody(body);
        this.bodies.push(body);

        return body;
    }

    createBox(size, mass, position) {
        const shape = new CANNON.Box(new CANNON.Vec3(size.x/2, size.y/2, size.z/2));
        const body = new CANNON.Body({
            mass: mass,
            shape: shape,
            position: new CANNON.Vec3(position.x, position.y, position.z)
        });

        this.world.addBody(body);
        this.bodies.push(body);

        return body;
    }

    createParticle(mass, position, velocity) {
        const shape = new CANNON.Particle();
        const body = new CANNON.Body({
            mass: mass,
            shape: shape,
            position: new CANNON.Vec3(position.x, position.y, position.z),
            velocity: new CANNON.Vec3(velocity.x, velocity.y, velocity.z)
        });

        this.world.addBody(body);
        this.bodies.push(body);

        return body;
    }

    addForce(body, force) {
        body.applyForce(
            new CANNON.Vec3(force.x, force.y, force.z),
            body.position
        );
    }

    removeBody(body) {
        this.world.removeBody(body);
        const index = this.bodies.indexOf(body);
        if (index > -1) {
            this.bodies.splice(index, 1);
        }
    }

    update(deltaTime) {
        this.world.step(this.timeStep, deltaTime, 3);
    }

    reset() {
        this.bodies.forEach(body => {
            this.world.removeBody(body);
        });
        this.bodies = [];
        this.meshes = [];
    }

    getWorld() {
        return this.world;
    }
}